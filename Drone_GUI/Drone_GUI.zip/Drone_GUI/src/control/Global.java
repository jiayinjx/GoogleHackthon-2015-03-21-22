package control;

public class Global {
	public static SearchEngine searchEngine;
	public static String database = "University.txt";
}
